#include <stdio.h>
#include <cs50.h>
#include <math.h>
#include <ctype.h>
#include <string.h>

int main(void)
{
    //l = letters
    //w = words
    //s = sentences
    
    int l, w, s;
    l = w = s = 0;
    string t = get_string(" Text:");
    
    int n = strlen(t);
    for (int i = 0; i < n; i++)
    {
        if (isalpha(t[i]))
        {
            l++;
        }
        
        if ((i == 0 && t[i] != ' ') 
            || (i != n - 1 && t[i] == ' ' && t[i + 1] != ' '))
        {
            w++;
        }
       
        //Not accurate for words like "Mr." or "Ms."
        if (t[i] == '.' || t[i] == '!' || t[i] == '?')
        {
            s++;
        }
    }
    
    //Use float to get more accurate data
    float L = l / (float) w * 100;
    float S = s / (float) w * 100;
    int index = round(0.0588 * L - 0.296 * S - 15.8);
    
    if (index < 1)
    {
        printf("Before Grade 1\n");
    }
    
    else if (index >= 16)
    {
        printf("Grade 16+\n");
    }
    
    else
    {
        printf("Grade %i\n", index);
    }
    
}

