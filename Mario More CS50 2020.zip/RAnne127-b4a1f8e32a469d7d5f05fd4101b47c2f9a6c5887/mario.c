#include <cs50.h>
#include <stdio.h>
void print(char c, int n);

int main(void)
{
    int n;
    do
    {
        //Prompt height
        n =  get_int("Height: ");
    }
    // Integers 1 to 8
    while (n < 1 || n > 8); 

    for (int i = 0; i < n; i++)  
    {
        //i=0
        print(' ', n - 1 - i);

        //i = 1
        print('#', i + 1);
        
        //i = 2
        print(' ', 2);
        
        //i = 3
        print('#', i + 1);

        //Newline
        printf("\n");
    }
}

void print(char c, int n)
{
    for (int i = 0; i < n; i++)
    {
        printf("%c", c);
    }
}
