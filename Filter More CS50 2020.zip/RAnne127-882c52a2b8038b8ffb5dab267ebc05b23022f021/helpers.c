#include "helpers.h"
#include <cs50.h>
#include <math.h>

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            RGBTRIPLE pixel = image[i][j];
            int average = round((pixel.rgbtRed + pixel.rgbtGreen + pixel.rgbtBlue) / 3.0);
            image[i][j].rgbtRed = image[i][j].rgbtGreen = image[i][j].rgbtBlue = average;
        }
    }
}


void swap(RGBTRIPLE *pixel1, RGBTRIPLE *pixel2)
{
    RGBTRIPLE temp = *pixel1;
    *pixel1 = *pixel2;
    *pixel2 = temp  ;
}
// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width / 2; j++)
        {
            // Reflection [0  , end - 1]
            // Reflection[1  , end - 2]
            swap(&image[i][j], &image[i][width - 1 - j]);
        }
    }
}


//Checking if it is a valid pixel
bool valid_pixel(int i, int j, int height, int width)
{
    return i >= 0 && i < height && j >= 0 && j < width;
}

//Getting blurred pixel 
RGBTRIPLE blur_pixel(int i, int j, int height, int width, RGBTRIPLE image[height][width])
{
    int redValue, greenValue, blueValue; 
    redValue = greenValue = blueValue = 0;
    int NumOfValidPixels = 0;
    for (int di = -1; di <= 1; di++) // -1 for left
    {
        for (int dj = -1; dj <= 1; dj++)
        {
            int new_i = i + di; //distance i
            int new_j = j + dj; //distance j
            if (valid_pixel(new_i, new_j, height, width))
            {
                NumOfValidPixels++;
                redValue += image[new_i][new_j].rgbtRed; //Adding the color of neighboring pixels
                greenValue += image[new_i][new_j].rgbtGreen;
                blueValue += image[new_i][new_j].rgbtBlue;
            }
        }
    }
    RGBTRIPLE blurred_pixel;
    blurred_pixel.rgbtRed = round((float) redValue / NumOfValidPixels); //Use float for precision and rounf for integer.
    blurred_pixel.rgbtGreen = round((float) greenValue / NumOfValidPixels);
    blurred_pixel.rgbtBlue = round((float) blueValue / NumOfValidPixels);
    return blurred_pixel;
}
// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE new_image[height][width];
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            new_image[i][j] = blur_pixel(i, j, height, width, image);
        }
    }
    //Saving copy of new image 
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            image[i][j] = new_image[i][j];  
        }
    }
}

int cap(int value)
{
    //If value is < 255, return that value. Otherwise, return 255 as value.
    return value < 255 ? value : 255;
}
RGBTRIPLE get_edged_pixel(int i, int j, int height, int width, RGBTRIPLE image[height][width])
{
    int Gx[3][3] = {{-1, 0, 1}, {-2, 0, 2}, {-1, 0, 1}};
    int redValueX, greenValueX, blueValueX, redValueY, greenValueY, blueValueY;
    redValueX = greenValueX = blueValueX = redValueY = greenValueY = blueValueY = 0;    
    
    for (int di = -1 ; di <= 1; di++)
    {
        for (int dj = -1; dj <= 1; dj++)
        {
            if (valid_pixel(i + di, j + dj, height, width))
            {
                int weightX = Gx[di + 1][dj + 1];
                redValueX += weightX * image[i + di][j + dj].rgbtRed;
                greenValueX += weightX * image[i + di][j + dj].rgbtGreen;
                blueValueX += weightX * image[i + di][j + dj].rgbtBlue;
                
                int weightY = Gx[dj + 1][di + 1];
                redValueY += weightY * image[i + di][j + dj].rgbtRed;
                greenValueY += weightY * image[i + di][j + dj].rgbtGreen;
                blueValueY += weightY * image[i + di][j + dj].rgbtBlue;
            }
        }
    }
    //New channel value = sqrt(Gx^2 + Gy^2)
    RGBTRIPLE pixel;
    pixel.rgbtRed = cap(round(sqrt(redValueX * redValueX + redValueY * redValueY)));
    pixel.rgbtGreen = cap(round(sqrt(greenValueX * greenValueX + greenValueY * greenValueY)));
    pixel.rgbtBlue = cap(round(sqrt(blueValueX * blueValueX + blueValueY * blueValueY)));
    return pixel;
}
// Detect edges
void edges(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE new_image[height][width];
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            new_image[i][j] = get_edged_pixel(i, j, height, width, image);
        }
    }
    
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            image[i][j] = new_image[i][j];
        }
    }
}
