#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <cs50.h>
typedef uint8_t BYTE;
#define FILE_NAME_SIZE 8
#define BLOCK_SIZE 512
bool start_new_jpeg(BYTE buffer[]);



int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        printf("Usage: ./recovery image\n");
        return 1;
    }
    //Open argv[1] as file entitled as infile
    FILE *infile = fopen(argv[1], "r");
    //Return error if file can't be opened
    if (infile == NULL)
    {
        printf("File not found\n");
        return 1;
    }
    
    //Make a byte entitled as buffer of size 512(defined above)
    BYTE buffer[BLOCK_SIZE];
    
    bool found_first_jpg = false;
    //Setting name of file as outfile
    FILE *outfile;
    //Make a file index
    int file_index = 0;
    //File reading of buffer one byte at a time
    while (fread(buffer, BLOCK_SIZE, 1, infile))
    {
        if (start_new_jpeg(buffer))
        {
            if (!found_first_jpg)
            {
                found_first_jpg = true;
            }
            else
            {
                fclose(outfile);
            }
            char filename[FILE_NAME_SIZE];
            //Print as spring format for filename
            sprintf(filename, "%03i.jpg", file_index++);
            outfile = fopen(filename, "w");
            if (outfile == NULL)
            {
                return 1;
            }
            fwrite(buffer, BLOCK_SIZE, 1, outfile);
        }
        else if (found_first_jpg)
        {
            //Keep writing the file
            fwrite(buffer, BLOCK_SIZE, 1, outfile);
        }
    }
    fclose(outfile);
    fclose(infile);
}


//Checking the start bytes for jpeg
bool start_new_jpeg(BYTE buffer[])
{
    return buffer[0] == 0xff && buffer[1] == 0xd8 && buffer[2] == 0xff && (buffer[3] & 0xf0) == 0xe0;
}