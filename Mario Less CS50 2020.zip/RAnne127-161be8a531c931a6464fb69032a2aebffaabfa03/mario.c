#include <cs50.h>
#include <stdio.h>

int main(void)
{
    //Get height
    int n;
    do
    {
        n = get_int("Height: ");
    }
    while (n < 1 || n > 8);

    //For loop (inside and outside)
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (i + j < n - 1)

            {
                //Space
                printf(" ");
            }
                 

            else
            {  
                //Hash         
                printf("#");    
            }
                
        }
        //New line
        printf("\n");
    }

}
