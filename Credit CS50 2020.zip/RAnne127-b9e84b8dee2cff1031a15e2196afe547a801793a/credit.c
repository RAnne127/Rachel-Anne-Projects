#include <stdio.h>
#include <cs50.h>
bool cvalid(long long cc);
int find_length(long long k);
bool checksum(long long n);
void print_cb(long long n);


int main(void)
{
    //cc = credit card number
    long long cc; 
    do
    {
        cc = get_long_long("Number: ");
    }
    while (cc < 0);

    //cv = check validity; cb = credit card brand
    if (cvalid(cc) == true)
    {
        print_cb(cc);
    }
        
    else
    {
        printf("INVALID\n");
    }                
}

// cvalid function
bool cvalid(long long cc)
{
    //l=length
    int len =  find_length(cc);
    return (len == 13 || len == 15 || len == 16) && checksum(cc);
}

int find_length(long long k)
{
    int len;
    for (len = 0; k != 0; k /= 10, len++);
    return len              ;
}

//checksum function
bool checksum(long long n)
{
    int sum = 0;
    for (int i = 0; n != 0; i++, n /= 10)
    {
        if (i % 2 == 0)     
        {
            sum += n % 10;
        }
      
        else
        {
            int digit = 2 * (n % 10);
            sum += digit / 10 + digit % 10;
        }        
    }
    return (sum % 10) == 0;
}   

//print_cb function 
void print_cb(long long n)
{
    //for AMEX
    if ((n >= 34e13 && n < 35e13) || (n >= 37e13 && n < 38e13))
    { 
        printf("AMEX\n");
    }
        
    //for MASTERCARD
    else if (n >= 51e14 && n < 56e14)
    {
        printf("MASTERCARD\n");
    }
        
    //for VISA
    else if ((n >= 4e12 && n < 5e12) || (n >= 4e15 && n < 5e15))
    {
        printf("VISA\n");
    }
        
    else
    {
        printf("INVALID\n");
    } 
        
}
