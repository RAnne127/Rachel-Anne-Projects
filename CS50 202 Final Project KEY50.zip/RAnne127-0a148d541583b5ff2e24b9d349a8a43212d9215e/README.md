CS50x Final Project: KEY50

KEY50 is a web-based application using JavaScript, Python, and SQL. This project generates suggested strong and random passwords composed of letters, numbers, and symbols.

How the webpage works?
The user will first register to be able to use the password generator. During the registration you need to fill-up these fields:
username
password
password confirmation (checks if the passwords match)
After the user is registered, the webpage will direct the user to login using the registered username and password. Once the user has logged-in, the webpage will direct the user to the password generator. Generate password button allows the user to generate random password again again. A copy button will also copy the generated password and triggers an alert that says that the code was successfully copied on clip board.

Sessions
 The webpage uses sessions to confirm that the user is registered. Once the user logins, his/her credentials are encrypted. The webpage will hash the password.

Database
Database stores the username of the user and hashed passwords. It does not save the password itself.

How to launch application:
Run the following on CS50 IDE terminal:
export API_KEY=<key>
run flask