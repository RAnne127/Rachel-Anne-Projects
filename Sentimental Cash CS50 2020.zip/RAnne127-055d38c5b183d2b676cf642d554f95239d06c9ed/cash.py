from cs50 import get_float

# Prompt for dollars; ex: $0.41
while True:
    d = get_float("Changed owed:")
    if d > 0:
        break
# Convert dollars to cents
cents = round(d * 100)

# n represents number of coins
n = 0

# Variants of money
variants = [25, 10, 5, 1]

# Note for "var" in variants notations
for var in variants:
    # //= integer division; Increase no. of coins
    n += cents // var
    # Update cents to the remainder
    cents %= var

print(n)
