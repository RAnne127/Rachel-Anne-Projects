from cs50 import get_int

# Make a main() function


def main():
    # Promt for credit card number
    while True:
        cc = get_int("Number:")
        if cc > 0:
            break

    # Check card validity
    if cvalid(cc):
        print_cb(cc)
    else:
        print("INVALID")


# cvalid() function

def cvalid(cc):
    return checksum(cc)
    

# checksum() function

def checksum(cc):
    # Initialize sum
    sum = 0
    # Convert cc (integer) to string
    for i in range(len(str(cc))):
        if (i % 2 == 0):
            sum += cc % 10
        else:
            digit = 2 * (cc % 10)
            # Integer division = //
            sum += digit // 10 + digit % 10
        cc //= 10
    return sum % 10 == 0
    

# print_cb() function

def print_cb(cc):
    # AMEX card
    if (cc >= 34e13 and cc < 35e13) or (cc >= 37e13 and cc < 38e13):
        print("AMEX")
    # MASTERCARD
    elif cc >= 51e14 and cc < 56e14:
        print("MASTERCARD")
    # VISA card
    elif (cc >= 4e12 and cc < 5e12) or (cc >= 4e15 and cc < 5e15):
        print("VISA")
    # INVALID
    else:
        print("INVALID")


# Running main() function in Python
if __name__ == "__main__":
    main()
