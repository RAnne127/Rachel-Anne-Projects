from cs50 import get_int

# N represents the height of pyramid
n = get_int("Height: ")

# Prompt for n if n is outside the parameter
while n < 1 or n > 8:
    n = get_int("Height: ")

# K represents number of hashes(left side)
k = 1

# Iterate over range of height
for i in range(n):
    print(" " * (n - i - 1), end="")
    print("#" * (i + 1), end="")
    print(" " * 2, end="")
    print("#" * (i + 1), end="")
    print(end="\n")