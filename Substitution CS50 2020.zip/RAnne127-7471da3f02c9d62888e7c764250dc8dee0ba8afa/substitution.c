#include <stdio.h>
#include <cs50.h>
#include <ctype.h>
#include <string.h>
bool validkey(string s);


int main(int argc, string argv[])
{
    //argument checking
    if (argc != 2)
    {
        printf("Usage: ./substitution key\n");
        return 1;
    }
    if (!validkey(argv[1]))
    {
        printf("Key must contain 26 characters.\n");
        return 1;
    }
    string s = get_string("plaintext:");
    string diff = argv[1];
    // Make alphabet 26 reference
    for (int i = 'A'; i <= 'Z'; i++)
    {
        diff[i - 'A'] = toupper(diff[i - 'A']) - i; // 'J' to 'A'
    }
    //Printing ciphertext
    printf("ciphertext:");
    for (int i = 0, len = strlen(s); i < len; i++)
    {
        if (isalpha(s[i]))
        {
            s[i] = s[i] + diff[s[i] - (isupper(s[i]) ? 'A' : 'a')]; // Take note of brakets
        }
        printf("%c", s[i]);
    }
    printf("\n");
}

//validkey function
bool validkey(string s)
{
    int len = strlen(s);
    if (len != 26)
    {
        return false;
    }
    //Setting frequency to zero for all alphabet reference
    int frequency[26] = {0};
    for (int i = 0; i < len; i++)
    {
        if (!isalpha(s[1]))
        {
            return false;
        }
        int index = toupper(s[i]) - 'A';
        if (frequency[index] > 0)
        {
            return false;
        }
        frequency[index]++;
    }
    return true;
}