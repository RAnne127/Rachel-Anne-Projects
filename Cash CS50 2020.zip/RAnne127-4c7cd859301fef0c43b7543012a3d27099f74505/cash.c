#include <stdio.h>
#include <cs50.h>
#include <math.h>

int main(void)
{
    
    //d = dollars
    float d;
    do
    {
        d = get_float("Changed owed:");
    }
    while (d < 0);

    //c =  cents
    int c = round(d * 100);
    //n = coins
    int n = 0;

    //m = money; s = size
    int m[] = {25, 10, 5, 1};
    int s =  sizeof(m) / sizeof(int);
   
    for (int i = 0; i < s; i++)
    {
        n += c / m[i];
        c %= m[i];
    }

    printf("%i\n", n);

}
