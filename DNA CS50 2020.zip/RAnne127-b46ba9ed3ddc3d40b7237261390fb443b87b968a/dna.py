from sys import argv, exit
import csv


# Get the maximum number of STRs(sub) in DNA sequence(s)
def get_max_substrings(s, sub):
    #[AGAGGGAGG] = [30201002001]
    ans = [0] * len(s)
    # for (int i = strlen(s)- strlen(sub); i > -1; i--);look through each character per length of STR
    for i in range(len(s) - len(sub), -1, -1):
        if s[i: i + len(sub)] == sub:
            # To determine if STR can fit to remaining sequence
            if i + len(sub) > len(s) - 1:
                ans[i] = 1
            else:
                ans[i] = 1 + ans[i + len(sub)]
    return max(ans)


def print_match(reader, actual_dna):
    # Look through each row
    for line in reader:
        person_name = line[0]
        # Make a list for every value in rows starting from element 1 to end
        values = [int(val) for val in line[1:]]
        # Compare the list
        if values == actual_dna:
            print(person_name)
            return
    print("No match")


def main():
    # Prompt for usage
    if len(argv) != 3:
        print("Usage: python dna.py data.csv sequence.txt")
        exit(1)

    # With open function automatically closes a file if NULL
    csv_path = argv[1]
    with open(csv_path) as csv_file:
        reader = csv.reader(csv_file)

        all_seq = next(reader)[1:]

        txt_path = argv[2]
        with open(txt_path) as txt_file:
            s = txt_file.read()
            actual_dna = [get_max_substrings(s, seq) for seq in all_seq]

        print_match(reader, actual_dna)


# Running main function in Python
if __name__ == "__main__":
    main()