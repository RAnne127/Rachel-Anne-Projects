#include <stdio.h>
#include <cs50.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
bool check_key(string s);

int main(int argc, string argv[])
{
    //Getting the valid key; k =  key
    if (argc != 2 || !check_key(argv[1]))  
    {
        printf("Usage: ./caesar key\n");
        return 1;
    }
    //ASCII string to interger ("27" to 27)
    int k = atoi(argv[1]); 
    
    //Get the plaintext
    string text =  get_string("plaintext:");
    
    //printing the ciphertext
    printf("ciphertext:");
    int n = strlen(text);
    for (int i = 0; i < n; i++)
    {
        char x = text[i];
        if (isalpha(x)) //(checking if it's alphabet)
        {
            char y = 'A';
            if (islower(x))
            {
                y = 'a';
            }
            // Use %c for printing characters
            printf("%c", ((x - y + k) % 26 + y));
        }
        else
        {
            printf("%c", x);
        }
    }
    printf("\n");
}

// checky_ key function
bool check_key(string s)
{
    int z = strlen(s);
    for (int i = 0; i < z; i++)
    {
        //Checking that it is not digit
        if (!isdigit(s[i]))
        {
            return false;
        }
    }
    return true;
}

