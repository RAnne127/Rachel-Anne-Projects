// Implements a dictionary's functionality

#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <strings.h>

#include "dictionary.h"


// Represents a node in a hash table
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
}
node;

// Number of buckets in hash table
const unsigned int N = 27;                                                     
int total_words = 0;                                                            
bool is_loaded = false;                                                        

// Hash table
node *table[N];

// Returns true if word is in dictionary; else false
bool check(const char *word)
{
    int i = hash(word);
    if (table[i] == NULL)
    {
        return false;
    }
    for (node *cursor = table[i]; cursor != NULL; cursor = cursor->next)
    {
        if (strcasecmp(word, cursor->word) == 0)                                
        {
            return true;
        }
    }
    return false;
}

// Hashes word to a number
unsigned int hash(const char *word)                                             
{
    char x;
    x = tolower(word[0]);
    int hash = x;
    hash -= 97;
    return hash;
}

// Loads dictionary into memory, returning true if successful else false
bool load(const char *dictionary)
{
    FILE *infile = fopen(dictionary, "r");
    if (infile == NULL)                                                              
    {
        printf("File not found\n");
        return false;
    }

    for (int i = 0; i < N; i++)
    {
        //Set all pointers in each node to NULL
        table[i] = NULL;                                                        
    }

    //Add 1 for NUL
    char new_word[LENGTH + 1];

    while (fscanf(infile, "%s", new_word) != EOF)
    {
        node *new_node = malloc(sizeof(node));

        if (new_node == NULL)
        {
            return false;
        }

        int k = hash(new_word);
        strcpy(new_node->word, new_word);

        if (table[k] == NULL)
        {
            new_node->next = NULL;
            table[k] = new_node;
            total_words++;
        }

        else
        {
            new_node->next = table[k];
            table[k] = new_node;
            total_words++;
        }
    }
    fclose(infile);
    is_loaded = true;
    return true;
}

// Returns number of words in dictionary if loaded else 0 if not yet loaded
unsigned int size(void)
{
    if (is_loaded == true)
    {
        return total_words;
    }
    else
    {
        return 0;
    }
}
// Unloads dictionary from memory, returning true if successful else false
bool unload(void)
{
    for (int i = 0; i <= N; i++)
    {
        if (table[i] != NULL)
        {
            node *p = table[i];
            while (p != NULL)
            {
                node *tmp = p;
                p = p->next;
                free(tmp);
            }
        }
    }
    return true;
}