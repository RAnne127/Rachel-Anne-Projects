from cs50 import get_string

# Initialize words, sentences, and letters
l, s, w = 0, 0, 0
# strip removes whitespaces from either side of the string
t = get_string("Text:").strip()

n = len(t)

for i in range(n):
    # isalpha() is present in python
    # Increment letters
    if t[i].isalpha():
        l += 1
    # Increment words
    if (i == 0 and t[i] != ' ') or (i != n - 1 and t[i] == ' ' and t[i + 1] != ' '):
        w += 1
    # Increment sentences
    if (t[i] == '.' or t[i] == '!' or t[i] == '?'):
        s += 1

# L is the average number of letters per 100 words in the text
L = l / w * 100
# S is the average number of sentences per 100 words in the text.
S = s / w * 100
# Coleman-Liau index
index = round(0.0588 * L - 0.296 * S - 15.8)

if index < 1:
    print("Before Grade 1")
elif index >= 16:
    print("Grade 16+")
else:
    print("Grade", index)
