SELECT COUNT(*) AS Num_Movies_10
    FROM ratings
    WHERE rating == 10;